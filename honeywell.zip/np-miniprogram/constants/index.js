const config = {
	telephone: '400 880 7030',
	website: 'https://mp.weixin.qq.com/s/DRj-ipwnGAv0NFB-HHYfsQ',
	miniprogramAppid: 'wxad85729177202842'
}

export default config