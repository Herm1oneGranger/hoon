const getters = {
  userInfo: state => state.user.info,
}

export default getters
