package com.bosch.web.domain.vo;

import lombok.Data;

@Data
public class RecordVo {
    private String checkedDate;
    private Integer number;
    private String province;
    private String city;
}
