package com.bosch.web.domain.vo;

import lombok.Data;

@Data
public class ReportData {
    private long allCheckedRecord;
    private long allActivatedLabel;
    private long allCheckedPeople;
    private long allRiskRecord;
}
