export const UseStartupChart = false
export const IsUseSysTitle = false
export const BuiltInServerPort = 25565
export const hotPublishUrl = ""
export const hotPublishConfigName = "update-config"
export const openDevTools = false
export const DisableF12 = true