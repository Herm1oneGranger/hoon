import { hotPublishUrl, hotPublishConfigName } from './const'

export const hotPublishConfig = {
    url: hotPublishUrl,
    configName: hotPublishConfigName
}