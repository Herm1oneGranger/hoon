const menu = [
  {
    label: '设置',
    submenu: [{
      label: '退出',
      accelerator: 'CmdOrCtrl+F4',
      role: 'close'
    }]
  },
]

export default menu
