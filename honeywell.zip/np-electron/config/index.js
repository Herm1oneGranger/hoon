module.exports = {
  build: {
    cleanConsole: true,
  },
  dev: {
    removeElectronJunk: true,
    chineseLog: false,
    port: 9080
  },
  DllFolder: '',
  UseJsx: true
}
